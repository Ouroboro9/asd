#ifndef __NOUVEAU_PPP_H__
#define __NOUVEAU_PPP_H__

extern struct nouveau_oclass nv98_ppp_oclass;
extern struct nouveau_oclass nvc0_ppp_oclass;

#endif
