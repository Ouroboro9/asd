#ifndef __NOUVEAU_COPY_H__
#define __NOUVEAU_COPY_H__

void nva3_copy_intr(struct nouveau_subdev *);

extern struct nouveau_oclass nva3_copy_oclass;
extern struct nouveau_oclass nvc0_copy0_oclass;
extern struct nouveau_oclass nvc0_copy1_oclass;
extern struct nouveau_oclass nve0_copy0_oclass;
extern struct nouveau_oclass nve0_copy1_oclass;

#endif
