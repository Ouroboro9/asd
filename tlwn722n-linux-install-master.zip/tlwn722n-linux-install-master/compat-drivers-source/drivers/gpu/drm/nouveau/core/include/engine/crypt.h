#ifndef __NOUVEAU_CRYPT_H__
#define __NOUVEAU_CRYPT_H__

extern struct nouveau_oclass nv84_crypt_oclass;
extern struct nouveau_oclass nv98_crypt_oclass;

#endif
