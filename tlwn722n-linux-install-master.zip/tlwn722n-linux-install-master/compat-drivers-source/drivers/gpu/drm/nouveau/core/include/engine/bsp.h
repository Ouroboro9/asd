#ifndef __NOUVEAU_BSP_H__
#define __NOUVEAU_BSP_H__

extern struct nouveau_oclass nv84_bsp_oclass;
extern struct nouveau_oclass nvc0_bsp_oclass;
extern struct nouveau_oclass nve0_bsp_oclass;

#endif
