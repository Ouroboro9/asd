#ifndef __NOUVEAU_VP_H__
#define __NOUVEAU_VP_H__

extern struct nouveau_oclass nv84_vp_oclass;
extern struct nouveau_oclass nvc0_vp_oclass;
extern struct nouveau_oclass nve0_vp_oclass;

#endif
