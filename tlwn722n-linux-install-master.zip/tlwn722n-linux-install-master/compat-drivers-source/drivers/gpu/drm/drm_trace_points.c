#include <drm/drmP.h>

#define CREATE_TRACE_POINTS
#include "drm_trace.h"
